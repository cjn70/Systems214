#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/time.h>

#include "mymalloc.h"
int Test_A(){
	int i = 0;
	struct timeval tv_i;
	struct timeval tv_f;
	long elapsed_time = 0;
	char * ptr;
	gettimeofday(&tv_i,0);
	for(i =0; i < 150; i++){
		ptr = (char*)malloc(sizeof(char)*1);
		if(ptr!= NULL){
			free(ptr);
		}
	}
	gettimeofday(&tv_f,0);
	elapsed_time = ((tv_f.tv_sec-tv_i.tv_sec)*1000000 + tv_f.tv_usec - tv_i.tv_usec);
	return elapsed_time;
}
int Test_B(){
	struct timeval tv_i;
	struct timeval tv_f;
	long elapsed_time = 0;
	gettimeofday(&tv_i,0);
	int i = 0;
	int j =0;
	int num_iteration =0;
	int sucessful_mallocs = 0;
	int sucessful_frees = 0;
	char *arr[50];
	char * ptr;
	for(i =0; i < 3; i++){	
		for(j =0; j < 50; j++){
			ptr = (char*)malloc(sizeof(char)*1);
			arr[j] = ptr;
		
		}
		if(j == 50){
			j =0;
			for(j = 0; j < 50; j++){
				if(ptr!= NULL){
					free(arr[j]);
				}
			}
		}
	
	}
	gettimeofday(&tv_f,0);
	elapsed_time = ((tv_f.tv_sec-tv_i.tv_sec)*1000000 + tv_f.tv_usec - tv_i.tv_usec);
	return elapsed_time;
}
int Test_C(){
	struct timeval tv_i;
	struct timeval tv_f;
	long elapsed_time = 0;
	gettimeofday(&tv_i,0);
	//random number generator either produces a 1 or a 0
	time_t t; 
	srand((unsigned) time(&t));
	int random = 0;
	int num_malloc =0;
	int i =0;
	char * ptr;
	char *arr[50];
	int location[50];
	int length = 0;
	int random2 = 0;
	int sucessful_malloc = 0;
	int sucessful_free = 0;
	//while-loop iterates until 50 bytes have been malloced
	while(num_malloc != 50){
		//chooses a random number between 1 and 0, 1 means to allocate memory, 0 means to free memory
		random = (rand() %2);
		if(random == 1){
			ptr = (char*)malloc(sizeof(char)*1);
			arr[length] = ptr;
			//this is my second array, if that index was allocated it is set to 1 in the location array.
			location[length] = 1;
			length++;	
			num_malloc ++;
			sucessful_malloc++;
		}
		//frees when number of mallocs is greater than 0 and less than 50 
		if(length != 0 && num_malloc != 0 && random == 0 ){
			//choose a random number between 0 and the number of indexes allocated
			for(i =0; i < 50; i++){
				random2 = (rand()% length + 0);
				if(location[random2] != -1){
					break;
				}	
			}
			//makes sure that that index at location does not = -1
			if(location[random2]!= -1){
				free(arr[random2]);
				
			}
			//place -1 in that location signaling that the pointer has been freed at that index
			location[random2] = -1;
			random2 = 0;
		}
		
	}
	//freeing the remaining pointers 
	//int left_over = sucessful_malloc-sucessful_free;
	for(i =0; i < 50; i++){
		if(location[i] != -1){
			free(arr[i]);
			
		}
	}
	gettimeofday(&tv_f,0);
	elapsed_time = ((tv_f.tv_sec-tv_i.tv_sec)*1000000 + tv_f.tv_usec - tv_i.tv_usec);
	return elapsed_time;
}

int Test_D(){
	struct timeval tv_i;
	struct timeval tv_f;
	long elapsed_time = 0;
	gettimeofday(&tv_i,0);
	int total = 0;
	time_t t;
	srand((unsigned) time(&t));
	int random = 0;
	int random2 = 0;
	int rand_size =0;
	int num_malloc =0;
	int i =0;
	char * ptr;
	char *arr[50];
	int location[50];
	int length = 0;
	while(num_malloc!=50){
		//chooses random number 1 or 0
		random = (rand() % 2);
		//chooses random number 1 to 64
		rand_size = (rand()% 64 +1);
		if(random == 1){		
			total += rand_size+2;
			if(total < 4096){
				ptr = (char*)malloc(sizeof(char)*rand_size);
				arr[length] = ptr;
				location[length] = 1;
				num_malloc++;
				length++;
			}
		}
		if(length != 0 && num_malloc != 0 && random == 0 ){
			//choose a random number between 0 and the number of indexes allocated
			for(i =0; i < 50; i++){
				random2 = (rand()% length + 0);
				if(location[random2] != -1){
					break;
				}	
			}
			//makes sure that that index at location does not = -1
			if(location[random2]!= -1){
				free(arr[random2]);
			}
			//place -1 in that location signaling that the pointer has been freed at that index
			location[random2] = -1;
			random2 = 0;
		}
	
	}
	
	for(i =0; i < 50; i++){
		if(location[i] != -1){
			free(arr[i]);
			
		}
	}
	gettimeofday(&tv_f,0);
	elapsed_time = ((tv_f.tv_sec-tv_i.tv_sec)*1000000 + tv_f.tv_usec - tv_i.tv_usec);
	return elapsed_time;
}
//randomly allocates different datatypes until it has allocated memory 50 times
int Test_E(){
	struct timeval tv_i;
	struct timeval tv_f;
	long elapsed_time = 0;
	gettimeofday(&tv_i,0);
	void * ptr;
	void *arr[50];
	int length = 0;
	time_t t;
	srand((unsigned) time(&t));
	int random = 0;
	int randome_type;
	int num_malloc = 0;
	int total = 0;
	int i =0;
	while(num_malloc != 50){
		random = (rand() % 5 + 1);
		if(random == 1){
			ptr = (char*)malloc(sizeof(char)*1);
			arr[length] = ptr;
			length++;
			total += sizeof(char);
		}
		if(random == 2){
			ptr = (int*)malloc(sizeof(int)*1);
			arr[length] = ptr;
			length++;
			total+= sizeof(int);
		}
		if(random == 3){
			ptr = (double*)malloc(sizeof(double)*1);
			arr[length] = ptr;
			length++;
			total+= sizeof(double);
		}
		if(random == 4){
			ptr = (float*)malloc(sizeof(float)*1);
			arr[length] = ptr;
			length++;
			total+= sizeof(float);
		}
		if(random == 5){
			ptr = (short*)malloc(sizeof(short)*1);
			arr[length] = ptr;
			length++;
			total+= sizeof(short);
		}
		num_malloc++;
	}
	for(i =0; i< num_malloc; i++){
		free(arr[i]);
		
	}
	gettimeofday(&tv_f,0);
	elapsed_time = ((tv_f.tv_sec-tv_i.tv_sec)*1000000 + tv_f.tv_usec - tv_i.tv_usec);
	return elapsed_time;
}
int Test_F(){
	struct timeval tv_i;
	struct timeval tv_f;
	long elapsed_time = 0;
	gettimeofday(&tv_i,0);
	printf("\n");
	printf("\n");
	int * x;
	free(x);
	printf("\n");
	int y;
	free((int*) y);
	printf("\n");
	char *p = (char*)malloc(200);
	free(p+10);
	free(p);
	printf("\n");
	char * p1 = (char*)malloc(100);
	free(p1);
	free(p1);
	printf("\n");
	char *p2 = (char*)malloc(4097);
	printf("\n");
	char *p3 = (char*)malloc(4096-2);
	printf("\n");
	char *p4 = (char*)malloc(1);
	gettimeofday(&tv_f,0);
	elapsed_time = ((tv_f.tv_sec-tv_i.tv_sec)*1000000 + tv_f.tv_usec - tv_i.tv_usec);
	return elapsed_time;

}
int returnAverage(int times[])
{
	int j = 0;
	int total = 0;
	for(j = 0; j < 100; j++)
	{
		total += times[j];	
	}
	return total/100;
}
int main(int argc, char * argv[]){
	int times[100];
	int i = 0;
	
	printf("\033[0;33mTest Case A: \033[0mmalloc 1 byte and immediately free it, do this 150 times\n");
	for(i = 0; i < 100; i++)
		times[i] = Test_A();
	printf("The average time elapsed for Test Case A is: %d microseconds\n", returnAverage(times));
	printf("\n\n\n");
	
	
	printf("\033[0;33mTest Case B: \033[0mmalloc 1 byte, store the pointer in an array. Once 50 bytes have been malloc()ed free the 50 byte pointer 1 by 1.\n");
	for(i = 0; i < 100; i++)
		times[i] = Test_B();
	printf("The average time elapsed for Test Case B is: %d microseconds\n", returnAverage(times));
	printf("\n\n\n");
	
	
	printf("\033[0;33mTest Case C: \033[0mRandomly choose between a 1 byte malloc or freeing the 1 byte pointer\n");
	for(i = 0; i < 100; i++)
		times[i] = Test_C();
	printf("The average time elapsed for Test Case C is: %d microseconds\n", returnAverage(times));
	printf("\n\n\n");
	
	
	printf("\033[0;33mTest Case D: \033[0mRandomly choose between a 1-64 byte malloc or freeing a pointer\n");
	for(i = 0; i < 100; i++)
		times[i] = Test_D();
	printf("The average time elapsed for Test Case D is: %d microseconds\n", returnAverage(times));
	printf("\n\n\n");
	
	printf("\033[0;33mTest Case E: \033[0mRandomly allocates different datatypes until memory has been allocated 50 times\n");
	for(i = 0; i < 100; i++)
		times[i] = Test_E();
	printf("The average time elapsed for Test Case E is: %d microseconds\n", returnAverage(times));
	printf("\n\n\n");
	
	printf("\033[0;33mTest Case F: \033[0mTest if mymalloc and myfree detect errors of not enough memory aviable, or pointer unable to be freed.\n");
	//for(i = 0; i < 100; i++)
	//	times[i] = Test_F();
	/*This testcase produces many errors on purpose to show that our program handles error detection and as such I have commented out the loop to reduce unnecessary information*/
	//printf("The average time elapsed for Test Case F is: %d microseconds\n", returnAverage(times));
	
	Test_F();
	printf("\n\n\n");
		
	
	
	
	
	
	
	
	
    return 0;
}
