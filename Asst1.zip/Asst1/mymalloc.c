#include <stdlib.h>
#include <stdio.h>
#include "mymalloc.h"

void print(int n)
{
	int i = 0;
	for(i = 0; i < n; i++)
		printf("Storage[%d]: %d\n", i, storage[i]);
}

int find_nearest_allocatable_memory(size_t n, int START, int END)
{
	const static int size = 4096;
	int start_index = 0;
	int count = 0;
	int i = 0;
	
	for(i = 0; i < size; i++)
	{
		//If there is n concurrent allocatable bytes found, return the index where our start flag should be placed.
		//if(count == (n-1))
		if(count == n)
		{
			return start_index;
		}
		//
		if(storage[i] == START)
		{
			while(storage[i] != END)
				i++;
			//Reset counters
			count = 0;
			start_index = i+1;
		}
		else
			count++;
	}
	return -1;
}

void* mymalloc(size_t n, char* file, int line)
{
	const static int metadata = 2;
	const static char START = -77;
	const static char END = -58;
	if(n > 0)
	{
		int p = find_nearest_allocatable_memory(n+metadata, START, END);
		//Concurrent memory equal to the requested memory + the size of our metadata has been found
		if(p != - 1)
		{
			//Insert START and END flags to denote the location in our memory that has now been designated for use by the user
			storage[p] = START;
			storage[p+n+1] = END;
			//Return the address of the START flag + sizeof(char), which should be the byte directly after the flag is stored
			return &(storage[p+1]);
		}
		//Not enough memory has been found, throw an error and return NULL.
		else
		{
			printf("Error in %s at line %d:\nThere is not enough memory currently available to allocate for you.\n", file, line);
			return NULL;
		}
	}
	else
	{
		printf("Please attempt to malloc at least 1 byte\n", file, line);
		return NULL;
	}
}

void myfree(void* p, char* file, int line)
{
	const static char START = -77;
	const static char END = -58;
	static char* ptr1 = &storage[0];
	static char* ptr2 = &storage[4096];
	
	if((char *) p < (char *) ptr1 || (char *) p > (char *) ptr2)
		printf("Trying to free an address that was not malloced in %s at line %d during call of myfree(x)\n", file, line);
	else if(*((char *) p-1) != START)
		printf("Repeated freeing or not freeing a pointer returned by malloc in %s at line %d during call of myfree(x)\n", file, line);
	else
	{
		*((char *) p-1) = 0;
		int i = 1;
		while(*((char *) p+i) != END)
			i++;
		*((char *) p+i) = 0;
	}
}
