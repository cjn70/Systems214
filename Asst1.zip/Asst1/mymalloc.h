#ifndef _MYMALLOC_H
#define _MYMALLOC_H

#define malloc(x) mymalloc(x, __FILE__, __LINE__)
#define free(x) myfree(x, __FILE__, __LINE__)

static char storage[4096/sizeof(char)];
void* mymalloc(size_t size, char* filename, int linenum);
void myfree(void* p, char* filename, int linenum);
int find_nearest_allocatable_memory(size_t n, int START, int END);
void print(int n);

#endif
