#ifndef _HEADER_H
#define _HEADER_H
#define search(x1,x2,x3,x4,x5) psuedo_main(x1,x2,x3,x4,x5)
int psuedo_main(int* list, int array_size,int subarr_size, int num_threads, int target);
#endif
