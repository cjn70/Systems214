#include <stdlib.h>
#include <stdio.h>
#include "multitest.h"
#include <time.h>
#include <sys/time.h>
/*A simple search function
reutrns -1 if the goal was not found or
returns a value >=0 signifying that the goal was found.
*/
int helper(int * test_arr, int beg, int end, int target){
	int found =0;
	int i =0;
	int count= 0;
	for(i = beg; i < end; i++){
		if(count > 250){
			count = 0;
		}
		if(test_arr[i] == target){
			found = 1;
			return count;
		}
		count++;
	}
	if(found != 1){
		return -1;
	}
}//end of helper function

// creates multiple child processes that have the same parent
int psuedo_main(int *test_arr, int size, int subarr_size, int num_process, int target){
	int start = 0;
	int i = 0;
	int pid1 = 0;
	int done = 0;
	int k =1;
	int end = 0;
	int status = 0;
	int exit1 = 0;
	pid_t * pid_arr = (pid_t *)malloc(sizeof(int) * num_process);
	int section = subarr_size;	
	end = (section-1);
	printf("Running Iterative Multi-Process Search\n");
	for(i =0; i < num_process; i ++){
		//creating a child process
		pid_t pid = fork();
		//storing pid in an array
		pid_arr[i] = pid;
		if(pid == 0){
			
			done = helper(test_arr, start,end, target);
			//freeing the malloced array becuase each child process will have a malloced array
			free(test_arr);
			//exit() will send the exit signal			
			exit(done);	
		}
		start = (section *k);
		//prevents the process from searching out of bounds or segfaulting
		if(i == (num_process -2))
		{
			end = (size-1);	
		}
		else{
			end = ((start + section)-1);
		}
		k ++;
		
		
	}//end for loop

	i =0;
	//calling wait and getting the exit status
	for(i =0; i < num_process; i++){
		pid1 = waitpid(pid_arr[i],&status,0);
		//check to make sure child exited normally
		if(WIFEXITED(status)){
			//return the exit status of the child which consists of the lower 8 bits of the status argument
			if(WEXITSTATUS(status) >= 0 && WEXITSTATUS(status) != 255){
				exit1 =  (WEXITSTATUS(status) + (section * i));
			
			}
		
		}
		
	}//end of for loop
	free(pid_arr); 
	return exit1;

}
