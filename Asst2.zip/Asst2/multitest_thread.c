#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include "pthread.h"
#include "multitest.h"

typedef struct _arguments
{
	int thread_id;
	int sub_arr_size;
	int goal;
	int* start;
	int* end;
}arguments;

//"Search" function that takes in a structure containing {Thread ID, subarray size, goal # to find, pointer to the start of the subarray, pointer to the end of the subarray}.
//Returns a number between 0-250 if found and -1 if not
void* helper(void* arg)
{
	arguments *args = arg;
	//Initialize found to -1 such that if the goal index is not found in the subarray, then the exit status returned is -1.
	int* found = malloc(sizeof(int));
	*found = -1;
	int* temp = args->start;
	int i;
	for(i = 0; i < args->sub_arr_size; i++)
	{
		if(*(temp+i) == args->goal)
		{
			//Set found to the index the goal is located at in the total array, not the subarray.
			*found = (args->thread_id * args->sub_arr_size) + i;
			//Exit with status = our location found.
			pthread_exit(found);
		}
	}
	//Exit with status = -1
	pthread_exit(found);
	free(found);
}

int psuedo_main(int* list, int array_size, int subarr_size, int num_threads, int goal)
{
	printf("Running iterative multi-threaded search\n");
	int i;
	int number = 0;
	pthread_t tid;
	//Allocate space for structures to be filled with the parameters that must be sent in with the thread to the helper function
	arguments* args = (arguments*) malloc(sizeof(arguments) * num_threads);
	//Allocate space for all threads
	pthread_t* thread_holder = (pthread_t*) malloc(sizeof(pthread_t) * num_threads);

	for(i = 0; i < num_threads; i++)
	{
		//Initialize the "parameters" of the helper function into the structure we allocated space for previously.
		(args+i)->goal = goal;
		(args+i)->sub_arr_size = subarr_size;
		(args+i)->thread_id = i;
		(args+i)->start = list+(i*(args+i)->sub_arr_size);
		//If we are at the last thread, simply set the ending location to the end of the list to avoid out of bounds errors and seg faulting.
		if(i == num_threads-1)
			(args+i)->end = list+(array_size);
		else
			(args+i)->end = list+((i+1)*(args+i)->sub_arr_size)-1;
		
			
		pthread_create((thread_holder + i), NULL, helper, (void*) (args+i));	
	}
	void* holder;
	//Loop through all created threads and wait until they finish, or until the thread that found the goal # is found.
	for(i = 0; i < num_threads; i++)
	{
		//Wait for the thread to finish
		pthread_join(*(thread_holder + i), &holder);
		if(*(int*) holder != -1)
			//Return the index found
			number =  *(int*)holder;
	}
	free(args);
	free(thread_holder);
	return number;
}





















