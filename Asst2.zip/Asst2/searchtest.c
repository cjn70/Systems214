#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <math.h>
#include <limits.h>
#include <sys/time.h>
#include "multitest.h"
typedef struct _arguments
{
	int arr_size;
}arguments;

//used on Test_1 & 2
int testA(int* list, int array_size, int goal, int* times, int num_iterations)
{
	//initialize time variables
	struct timeval tv_i;
	struct timeval tv_f;
	int elapsed_time = 0;
	//initialize the size of our sub arrays and how many threads/proccesses we will need as a result.
	int i;
	int subarr_size = 250;
	int num_times = (int) ceil(((double) array_size)/(double) subarr_size);
	int index =0;
	int swap = 0;
	int temp =0;
	time_t t; 
	srand((unsigned) time(&t));
	
	for(i = 0; i < num_iterations; i++)
	{
		printf("Iteration number: %d\n", i);
		swap = rand() % array_size;
		gettimeofday(&tv_i,0);
		index = search(list, array_size, subarr_size, num_times, goal);
		gettimeofday(&tv_f,0);
		elapsed_time = ((tv_f.tv_sec-tv_i.tv_sec)*1000000 + tv_f.tv_usec - tv_i.tv_usec);
		//swapping index 
		temp = list[swap];
		list[swap] = goal;
		list[index] = temp;
		printf("Found the goal %d, at index %d, in %d microseconds\n\n", goal, index, elapsed_time);
		*(times+i) = elapsed_time;
	}
	return num_times;
}

//used on Test_3 
int testB(int* list, int array_size, int goal, int* times, int num_iterations,int section)
{
	//initialize time variables
	struct timeval tv_i;
	struct timeval tv_f;
	int elapsed_time = 0;
	//initialize the size of our sub arrays and how many threads/proccesses we will need as a result.
	int i;
	int subarr_size = (int)ceil((double)250/section);
	int num_times = (int) ceil(((double) array_size)/(double) subarr_size);
	int index = 0;
	int swap =0;
	int temp =0;
	
	for(i = 0; i < num_iterations; i++)
	{
		printf("Iteration number: %d\n", i);
		swap = rand() % array_size;
		gettimeofday(&tv_i,0);
		index = search(list, array_size, subarr_size, num_times, goal);
		gettimeofday(&tv_f,0);
		elapsed_time = ((tv_f.tv_sec-tv_i.tv_sec)*1000000 + tv_f.tv_usec - tv_i.tv_usec);
		//swapping index	
		temp = list[swap];
		list[swap] = goal;
		list[index] = temp;
		printf("Found the goal %d, at index %d, in %d microseconds\n\n", goal, index, elapsed_time);
		*(times+i) = elapsed_time;
	}
	return num_times;
}
//this function is used to calculate the average, min, and max
int min_max_average(int* times, int num_iterations)
{
	int min = INT_MAX;
	int max = INT_MIN;
	int total = 0;
	int i;
	
	for(i = 0; i < num_iterations; i++)
	{
		if(times[i] > max)
			max = times[i];
		else if(times[i] < min)
			min = times[i];
		total += times[i];
	}	
	int average = total/num_iterations;
	printf("Min: %d, Max: %d, Average %d\n", min, max, average);
	return average;
}
//this function is used to calculate the standard deviation
void std_dev(int* times, int num_iterations, int average)
{
	float total = 0.0;
	int i;
	for(i = 0; i < num_iterations; i++)
	{
		total += pow((times[i] - average), 2);
	}
	printf("Standard Deviation: %lf\n", sqrt(total/num_iterations));
	
}
// testing trend of time vs size from size 250 incrementing the size of the index by 1000 each iteration
void test_0(){
	int it = 0;
	int array_size = 250;
	int num_iterations = 100;
	int i = 0;
	int sectionA = 0;
	int* list;
	int* testA_times;
	int * avg;
	float stdev = 0;
	time_t t; 
	srand((unsigned) time(&t));
	for(it =0; it < 10 ; it++){
		 list = (int*)malloc(sizeof(int) * array_size);
		
		 testA_times = malloc(sizeof(int) * num_iterations);
		
		
		//Initialize array of size 'array_size' with values from 0 to 'array_size' - 1
		for(i = 0; i < array_size; i++)
		{
			list[i] = i;
		}
		
		//Scramble at least 3/4 as many random index pairs as the list is long
		for(i = 0; i <= (array_size * 0.75); i++)
		{
			int temp = list[i];
			int swap = rand() % array_size;
			list[i] = list[swap];
			list[swap] = temp;
		}
		//Deterministic or stochastic goal
		int goal = rand() % array_size;
		
		printf("\033[0;33m\nTest Case 0:Testing trend of time vs size from size 250 incrementing the size of each array by 1000 each iteration\033[0m\n");
		sectionA = testA(list, array_size, goal, testA_times, num_iterations);		
		printf("\n\nAll numbers are measured in microseconds!\n");
		#ifdef PROC
			printf("Array size: %d, Iterations: %d, Number of Processes created: %d\n", array_size, num_iterations,sectionA);
		#endif
		#ifdef THREAD
			printf("Array size: %d, Iterations: %d, Number of Threads created: %d\n", array_size, num_iterations,sectionA);
		#endif
		int testA_average = min_max_average(testA_times, num_iterations);
		std_dev(testA_times, num_iterations, testA_average);
		printf("\n");
	
		
		
		array_size = (array_size +1000);
	}
	
	free(list);
	free(testA_times);
	
}//end of the first test
//testing the trade off point of processes VS threads
test_1(){
	int array_size = 0;
	int num_iterations = 0;
	int i = 0;
	int section = 0;
	int* list;
	int* testA_times;
	int goal = 0;
	int it = 0;
	time_t t; 
	srand((unsigned) time(&t));
	#ifdef PROC
		array_size = 250;
		num_iterations = 100;
		i = 0;
		section = 0;
		list = (int*)malloc(sizeof(int) * array_size);
		testA_times = malloc(sizeof(int) * num_iterations);
		
		
		//Initialize array of size 'array_size' with values from 0 to 'array_size' - 1
		for(i = 0; i < array_size; i++)
		{
			list[i] = i;
		}
		
		//Scramble at least 3/4 as many random index pairs as the list is long
		for(i = 0; i <= (array_size * 0.75); i++)
		{
			int temp = list[i];
			int swap = rand() % array_size;
			list[i] = list[swap];
			list[swap] = temp;
		}
		//Deterministic or stochastic goal
		srand((unsigned) time(&t));
		goal = rand() % array_size;
		
		printf("\033[0;33m\nTest Case 1: Testing the trade off point of processes VS threads \033[0m\n");
		section = testB(list, array_size, goal, testA_times, num_iterations,1);
		
		
		
		printf("\n\nAll numbers are measured in microseconds!\n");
		printf("Array size: %d, Iterations: %d, Number of Processses created: %d\n", array_size, num_iterations,section);
		int testA_average = min_max_average(testA_times, num_iterations);
		std_dev(testA_times, num_iterations, testA_average);
		sleep(1);
		printf("\n");
		free(list);
		free(testA_times);
	#endif
	
	#ifdef THREAD
		array_size = 250;
		num_iterations = 100;
		i = 0;
		for(it = 0; it < 18; it ++){
			list = (int*)malloc(sizeof(int) * array_size);
			testA_times = malloc(sizeof(int) * num_iterations);
			
			//Initialize array of size 'array_size' with values from 0 to 'array_size' - 1
			for(i = 0; i < array_size; i++)
			{
				list[i] = i;
			}
			
			//Scramble at least 3/4 as many random index pairs as the list is long
			for(i = 0; i <= (array_size * 0.75); i++)
			{
				int temp = list[i];
				int swap = rand() % array_size;
				list[i] = list[swap];
				list[swap] = temp;
			}
			goal = rand() % array_size;
			
			printf("\033[0;33m\nTest Case 1: Testing the trade off point of processes VS threads \033[0m\n");
			section = testA(list, array_size, goal, testA_times, num_iterations);
			
			
			printf("\n\nAll numbers are measured in microseconds!\n");
			printf("Array size: %d, Iterations: %d, Number of Threads created: %d\n", array_size, num_iterations,section);
			int testA_average = min_max_average(testA_times, num_iterations);
			std_dev(testA_times, num_iterations, testA_average);
			printf("\n");
			array_size = (array_size + 500);
		}
		free(list);
		free(testA_times);
	#endif
	
	
	
}
//testing the tradeoff point for parallelims between Processes and Threads
test_2(){
	
	int array_size = 0;
	int num_iterations = 0;
	int i = 0;
	int section = 0;
	int portions = 1;
	int* list;
	int* testB_times;
	int goal = 0;
	char buffer[15];
	time_t t; 
	srand((unsigned) time(&t));
		array_size = 250;
		num_iterations = 100;
		i = 0;
		section = 0;
		list = (int*)malloc(sizeof(int) * array_size);
		testB_times = malloc(sizeof(int) * num_iterations);	
		//Initialize array of size 'array_size' with values from 0 to 'array_size' - 1
		for(i = 0; i < array_size; i++)
		{
			list[i] = i;
		}
		
		//Scramble at least 3/4 as many random index pairs as the list is long
		for(i = 0; i <= (array_size * 0.75); i++)
		{
			int temp = list[i];
			int swap = rand() % array_size;
			list[i] = list[swap];
			list[swap] = temp;
		}
		//Deterministic or stochastic goal
		
		goal = rand() % array_size;
		i = 0;
		for(i = 0; i < 15; i++){
			#ifdef PROC
				printf("\033[0;33m\nTest Case 2: Testing the Tradeoff Point of Parrallism for Processes \033[0m\n");
			#endif
			#ifdef THREAD
				printf("\033[0;33m\nTest Case 2: Testing the Tradeoff Point of Parrallism for Threads \033[0m\n");
			#endif
			section = testB(list, array_size, goal, testB_times, num_iterations,portions);
			printf("\n\nAll numbers are measured in microseconds!\n");
			#ifdef PROC
				printf("Array size: %d, Iterations: %d, Number of Processes created: %d\n", array_size, num_iterations,section);
			#endif
			#ifdef THREAD
				printf("Array size: %d, Iterations: %d, Number of Threads created %d\n",array_size,num_iterations,section);
			#endif
			int testB_average = min_max_average(testB_times, num_iterations);
			std_dev(testB_times, num_iterations, testB_average);
			//increasing the number of processes or threads
			portions = (portions +1);
			
		}
		free(list);
		free(testB_times);
	

}

int main(int argc, char * argv)
{
	
	
	test_0();
	test_1();
	test_2();


}













