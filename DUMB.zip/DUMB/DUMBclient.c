#include <netdb.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h>
#include <sys/types.h>
#include <errno.h> 
#include <ctype.h>
#include <netinet/in.h> 
#include <arpa/inet.h> 
#include <readline/readline.h>
#include <readline/history.h>
#define SA struct sockaddr
/*
ALERT- THE EXTRA CREADIT HAS BEEN IMPLEMENTED IN THIS PROJECT!!!!!!!!!!!!!!!
DESCRIPTION OF THE EXTRA CREDIT IS IN THE TESTPLAN.txt
*/
//this function counts the number of delimiters present in a string
int number(char * word,char del){
	int count = 1;
	int i = 0;
	for(i =0; i < strlen(word); i++){
		if(word[i] == del){
			count++;
		}
	}
	return count;
}
//this function returns an array of strings 
char ** parser(char * word,char del){
	int i = 0;
	int length = strlen(word);
	word[length] = '\0';
	int num_word = number(word,del);
	int charNum =0;
	int wordNum = 0;
	char ** parsed_word = malloc(sizeof(char*) *num_word);
	
	for(i = 0; i < num_word; i++){
		parsed_word[i] = malloc(sizeof(char*) * length);
	}
	
	for(i =0; i < length;i++){
		if(word[i] != del){
			parsed_word[wordNum][charNum] = word[i];
			charNum++;
		}
		else if(word[i] == del && word[i-1] == del){
			wordNum++;
			parsed_word[wordNum][charNum] = word[i];
			charNum = 0;
		}
		else if(word[i] == del){
			parsed_word[wordNum][charNum] = '\0';
			wordNum++;
			charNum =0;
		}
	}
	
	
	return parsed_word;
}
//this functions is used to calcuate the ascii values for the switch statement
int ascii_cal(char * word){
	int total =0;
	//int length = strlen(word);
	int i = 0;
	int j = 0;
	for(i =0; word[i]!= '\0';i++){
		if(isalpha(word[i])!= 0 && isupper(word[i]) == 0){

			total+= word[i];
			
		}
		
	}
	return total;
}
//this function is used to count the number of characters
int char_count(char* word){
	int i =0;
	int count =0;
	int space = 0;
	int number =0;
	int special = 0;
	for(i =0; word[i]!= '\0';i++){
		if(isalpha(word[i])!= 0){
			count++;
		}
		else if(isspace(word[i]) != 0){
			space++;
		}
		else if(isdigit(word[i]) > 0){
			number++;
		}
		else {
			special++;
		}
		
	}
	
	return (count + space+number+special);
}
//this function is used to display the help command
void help(){
	printf("List Of Commands That You Can Choose From\n");
	printf("quit\ncreate\ndelete\nopen\nclose\nnext\nput\n");

}
//used to count the number of arguments in the command line  
int arg_count(int argc){
	int count = 0;
	if(argc < 3){
		count = -1;
	}
	return count;
}
//function that creates the connection
int connection(int portno,struct hostent * server,int sockfd){
	struct sockaddr_in serv_addr;
	int conn =0;
	bzero((char *)&serv_addr,sizeof(serv_addr));
	serv_addr.sin_family= AF_INET;
	if(server != 0){
		memcpy(&serv_addr.sin_addr,server->h_addr_list[0],server->h_length);
	}
	else{
	
		return -1;
	}
	serv_addr.sin_port = htons(portno);
	conn = connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr));
	return conn;
}

int main(int argc, char *argv[]) 
{ 
	int sockfd, connfd; 
	struct sockaddr_in servaddr, cli; 
	int portno = 0;
	struct hostent * server;
	struct hostent * host_entry;
	char * hostname;
	int conn = -1;
	char buffer[19];
	char * inital_send;
	int size =0;
	char communication[1000];
	char * input;
	char * input1;
	char * input2;
	int i =0;
	char * port;
	char ** retry;
	char ** options;
	char ** put;
	int trys = 0;
	int n = 0;
	int count = 0;
	char * hello = "HELLO";
	//cheking to make sure that 3 arguments are being taken in from the command line
	if(argc < 3 || argc > 3){
		fprintf(stderr,"Incorrect amount of arguments have been entered\n");
		exit(0);
	}
	if(argc == 3 ){
		port = argv[2];
		hostname = argv[1];
	}
	char *IPbuffer;
	char host[256];
	int hostname1 = gethostname(host,sizeof(host));
	host_entry = gethostbyname(host);
	//getting the clients ip address
	IPbuffer = inet_ntoa(*((struct in_addr*) host_entry->h_addr_list[0]));
	//socket create and varification 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1){ 
		printf("socket creation failed...\n"); 
		exit(0); 
	} 
	bzero(&servaddr, sizeof(servaddr)); 
	//getting portnumber and server
	portno = atoi(port);
	server = gethostbyname(hostname);
	//checking to see if the correct credentials have been entered if not user has 3 tries
	while(i <= 3){	
		// connect the client socket to server socket	
		conn = connection(portno,server,sockfd);
		if(conn == 0){
			break;
		}
		//if the client did not connect 
		if(conn < 0){
			printf("Please Enter I.P or Hostname and Port Number: \n",strerror(errno));
			
			
		}
		//client program exits if user tried 3 times
		if(trys == 3){
			printf("Error: Ran Out of Attemps. Shutting Down!!!!!\n");
			free(retry);
			exit(0);
		}
		input = readline(NULL);
		retry = parser(input,' ');
		//re-attempting to access the server
		if(number(input,' ') > 1){
			port = retry[1];
			hostname = retry[0];
			portno = atoi(port);
			server = gethostbyname(hostname);
		}
		trys++;
		
	   i++;
	}
	//freeing retry array if retrys were needed
	if(trys > 1 && trys < 3){
		
		free(retry);
	}
        //sending the ip address to server
	write(sockfd,IPbuffer,50);
       	//sending HELLO to the server
	printf(">HELLO\n");
	char number2[4];
	write(sockfd,hello,5);
        read(sockfd,buffer,19);
	buffer[19]='\0';
	//Terminates connection if wrong message is sent from the server
	if(strcmp(buffer,"HELLO DUMBv0 ready!") != 0){
		
		printf("%s\n",buffer);
		exit(0);
	}
        printf("%s\n",buffer);
	bzero(buffer,19);
	//bzero(input, n);
	n = 0;
	int ascii = 0;
	int done = 0;
	char number3[4];
	//This while loop iterates until the user enters in the quit command
	while(done != 1){
		n = 0;
		printf(">");
		input1 = readline(NULL);
		ascii = ascii_cal(input1);
		//switch statement switches on the ascii code of the commands
		switch(ascii){
			//this case displays the help command
			case 425:
				help();
				break;
			//this case creates message boxes
			case 628:
				write(sockfd,"CREAT",strlen("CREAT"));
				printf("Enter in a message box to create.\n");
				printf("create:>");
				input2 = readline(NULL);
				sprintf(number3,"%d\n",char_count(input2));
				//printf("%s\n",number);
				write(sockfd,number3,4);
				int word_num = atoi(number3);
				write(sockfd,input2,word_num);
				char out[9];
				//bzero(input1, n);
				read(sockfd,out,9);
				out[9] = '\0';
				char again[9];
				size = read(sockfd,again,9);
				again[9] = '\0';
				input2[word_num] = '\0';
				if(strcmp(out,"OK!") == 0 && size == 1){
					printf("Success! Message box \'%s\' is now created.\n",input2);
				}
				if(strcmp(out,"ER:WHAT?") == 0 && size == 1){
					printf("Error. Command unsuccessful, Please try again.\n");
				}
				if(strcmp(again,"ER:EXIST") == 0 && size > 1){
					printf("Error. Message box \'%s\' already exists.\n",input2);
				}
				break;
			//this case deletes message boxes
			case 627:
				write(sockfd,"DELBX",strlen("DELBX"));
				printf("Delete which message box?\n");
				printf("delete:>");
				input2 = readline(NULL);
				sprintf(number3,"%d\n",char_count(input2));
				//printf("%s\n",number);
				write(sockfd,number3,4);
				word_num = atoi(number3);
				write(sockfd,input2,word_num);
				read(sockfd,out,9);
				out[9] = '\0';
				input2[word_num] = '\0';
				if(strcmp(out,"OK!") == 0){
					printf("Success! Message box \'%s\' is now deleted.\n",input2);
				}
				if(strcmp(out,"ER:NEXST") == 0){
					printf("Error. Message box \'%s\' dose not exist.\n",input2);
				}
				if(strcmp(out,"ER:OPEND") == 0){
					printf("Error. Message box \'%s\' is currently open .\n",input2);
				}
				if(strcmp(out,"ER:WHAT?") == 0){
					printf("Error. Command unsuccessful, Please try again.\n");
				}
				if(strcmp(out,"ER:NOTMT") == 0){
					printf("Error. The message box \'%s\'is not empty\n",input2);
				}
				
				break;
			//this case opens message boxes
			case 434:
				write(sockfd,"OPNBX",strlen("OPNBX"));
				printf("Open which message box?\n");
				printf("open:>");
				input2 = readline(NULL);
				sprintf(number3,"%d\n",char_count(input2));
				//printf("%s\n",number);
				write(sockfd,number3,4);
				word_num = atoi(number3);
				write(sockfd,input2,word_num);
				out[9];
				//bzero(input1, n);
				read(sockfd,out,9);
				out[9] = '\0';
				input2[word_num] = '\0';
				if(strcmp(out,"OK!") == 0){
					printf("Success! Message box \'%s\' is now open.\n",input2);
				}
				if(strcmp(out,"ER:NEXST") == 0){
					printf("Error. Message box dose not exist.\n");
				}
				if(strcmp(out,"ER:WHAT?") == 0){
					printf("Error. Command unsuccessful, Please try again.\n");
				}
				if(strcmp(out,"ER:OPEND") == 0){
					printf("Error. Message box is currently opened by another user.\n");
				}
				if(strcmp(out,"ER:ARLDY") == 0){
					printf("Error. You currently have a message box open.\n");
				}
				
				break;
			//this case closes message boxes
			case 534:
				write(sockfd,"CLSBX",strlen("CLSBX"));
				printf("Close which message box?\n");
				printf("close:>");
				input2 = readline(NULL);
				sprintf(number3,"%d\n",char_count(input2));
				//printf("%s\n",number);
				write(sockfd,number3,4);
				word_num = atoi(number3);
				write(sockfd,input2,word_num);
				read(sockfd,out,9);
				out[9] = '\0';
				input2[word_num] = '\0';
				if(strcmp(out,"OK!") == 0){
					printf("Success! Message box \'%s\' is now closed.\n",input2);
				}
				if(strcmp(out,"ER:NOOPN") == 0){
					printf("Error. Message box dose not exist or you do not have the message box \'%s\' open.\n",input2);
				}
				if(strcmp(out,"ER:WHAT?") == 0){
					printf("Error. Command unsuccessful, Please try again.\n");
				}
				break;
			//this case gets the messages from the message box
			case 447:
				write(sockfd,"NXTMG",strlen("NXTMG"));
				char server[9];
				server[9] = '\0';
				read(sockfd,server,9);
				char number4[1];
				int something =0;
				if(strcmp(server,"OK!") == 0){
					something = read(sockfd,number4,4);
					int length4 = atoi(number4);
					out[length4];
					read(sockfd,out,length4);
					out[length4] = '\0';
					printf("Success! Message \'%s\' has been removed from the queue.\n",out);
				}
				if(strcmp(server,"ER:EMPTY") == 0){
					printf("Error. Message box is empty.\n");
				}
				if(strcmp(server,"ER:NOOPN") == 0){
					printf("Error. You currently have no message box open.\n");
				}
				
				break;
			//this case puts the message into the message box
			case 345:
				write(sockfd,"PUTMG",strlen("PUTMG"));
				char error1[9];
				int error2 = read(sockfd,error1,9);
				//printf("Your have entered put\n");
				int last = char_count(input1);
				input1[last] = '\0';
				if(error2 == 1){
					printf("put:>");
					input2 = readline(NULL);
					int size = char_count(input2);
					write(sockfd,"OK!",9);					
					sprintf(number3,"%d\n",size);
					write(sockfd,number3,4);
					write(sockfd,input2,size);
					input2[size] = '\0';
					printf("Success! Message \'%s\' has been entered into the message box\n");
				}
				else if(error2 > 1){
					printf("Error. No message box open\n");
					write(sockfd,"ER:NOOPN",9);
				}
				break;
			//this case handles the quit commmand
			case 451:
				done = 1;
				write(sockfd,"GDBYE",strlen("GDBYE"));
				size = read(sockfd,communication,sizeof(communication));
				communication[sizeof(communication)] = '\0';
				if(size == 0){
					printf("Successful on Closing the Connection\n");
					
				}
				
				else{
					printf("Error Could Not Close Connection\n");
				}
				break;

			//this case handles bad command input
			default:
				if(ascii != 628){
					
					write(sockfd,"ERRRR",5);
					char nothing[9];
					read(sockfd,nothing,9);
					nothing[9] = '\0';
					printf("This is not a command from the command list enter \'help\'.\n");
				}
				break;
		}
		//breaks out of the loop if done == 1
		if(done == 1){
			break;
		}
		ascii =0;
		
	}
       // close the socket 
       close(sockfd); 
}
	

