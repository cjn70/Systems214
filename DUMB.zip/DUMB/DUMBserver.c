
#include <stdio.h> 
#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <time.h>
#include "fifo.h"
#include "pthread.h"
#include <fcntl.h>
#include <unistd.h>
#include <errno.h> 
#define SA struct sockaddr 
#define MAX_THREAD 30000
#define MAX_LOCK 20000
#define MAX_ATTR 20000
pthread_t id[MAX_THREAD];
pthread_mutex_t lock[MAX_LOCK]; 
pthread_mutexattr_t Attr[MAX_ATTR];
/*The lock create is used to prevent clients 
from simultaneously creating the same named
message box at the same time. Thus creating 
blocking synchronizaion.  
*/
pthread_mutex_t create;

//global variables being used
char ** word1;
char ** messages;
struct Queue **q;
int loc = 0;
int loc2 = 0;
int index1 = 0;
/*
 ALERT:THE EXTRA CREDIT HAS BEEN IMPLEMENTED IN THIS PROJECT!!!!!!!!!!!!!!
 FURHTER EXPLINATION OF THE EXTRA CREDIT IS IN THE TESTPLAN.TXT
*/
//This function displays the server events that are happening among each server operation and return 1 if their is a error server event
int server_events(char * message,char * IP,int err,int number1){
	time_t s, val = 1;
	struct tm* current_time;
	s = time(NULL);
	int hours, minutes, seconds;
	current_time = localtime(&s);
	hours = current_time->tm_hour;
	minutes = current_time->tm_min;
	int exit1 = 0;
	if(strcmp(message,"HELLO")==0){
		printf("%02d%02d %d %s %s %s\n",hours,minutes,current_time->tm_mday,"Dec",IP,"connected");
	}
	if(strcmp(message,"HELLO") == 0){
		if(err == 6){
			
			fprintf(stderr,"%d%d %d %s %s \n",hours,minutes,current_time->tm_mday,"Dec",IP);
			exit1 = 1;
			
		}
	}
	if(strcmp(message,"GDBYE")==0){
		printf("%02d%02d %d %s %s %s\n",hours,minutes,current_time->tm_mday,"Dec",IP,"disconnected");
	}
	if(strcmp(message,"CREAT") == 0){
		if(err > 0 && err < 4){
			
			fprintf(stderr,"%02d%02d %d %s %s ER:WHAT?\n",hours,minutes,current_time->tm_mday,"Dec",IP);
			exit1 = 1;
			
		}
	}
	if(strcmp(message,"CREAT") == 0){
		if(err  == 5){
			
			fprintf(stderr,"%02d%02d %d %s %s ER:EXIST?\n",hours,minutes,current_time->tm_mday,"Dec",IP);
			exit1 = 1;
			
		}
	}
	if(strcmp(message,"OPNBX") == 0){
		if(err > 0 && err < 4){
			
			fprintf(stderr,"%02d%02d %d %s %s ER:WHAT?\n",hours,minutes,current_time->tm_mday,"Dec",IP);
			exit1 = 1;
			
		}
	}
	if(strcmp(message,"OPNBX") == 0){
		if(err == 5){
			
			fprintf(stderr,"%02d%02d %d %s %s ER:NEXST\n",hours,minutes,current_time->tm_mday,"Dec",IP);
			exit1 = 1;
			
		}
	}
	if(strcmp(message,"ERRRR") == 0){
		if(err == 69){
			
			fprintf(stderr,"%02d%02d %d %s %s ER:WHAT?\n",hours,minutes,current_time->tm_mday,"Dec",IP);
			exit1 = 1;
			
		}
	}
	if(strcmp(message,"GDBYE") == 0 ||(strcmp(message,"CREAT") == 0 && err == 0)|| strcmp(message,"DELBX") == 0 || strcmp(message,"OPNBX") == 0 && err == 6 || strcmp(message,"CLSBX") == 0 || strcmp(message,"NXTMG") == 0 || strcmp(message,"PUTMG") == 0 || (strcmp(message,"HELLO") == 0 && err != 6)){
		printf("%02d%02d %d %s %s %s\n",hours,minutes,current_time->tm_mday,"Dec",IP,message);
		exit1 = 0;
		
	}
	
	return exit1;
	
}//end of function
//This function dynamincally exapnds when a message box is create thus increasing the number of queues.
struct Queue ** new(struct Queue ** old,int size){
	struct Queue ** new1 =(struct Queue **)malloc(sizeof(struct Queue)*(size));
	int i = 0;
	for(i =0; i < size;i++){
		new1[i] = old[i];
	}
	i=0;
	
	*(new1+(size)) = createQueue();

	
	return new1;	

}
//This function dynamically exapnds the array that holds the titles to each message box.
void ** word_arr(char ** old_arr,int length,int size){
	char **new = malloc(sizeof(char*)*size);
	int i = 0;
	new[size] = malloc(sizeof(char*)*length);
	for(i=0;i<size;i++){
		new[i] = old_arr[i];
	}
	word1 = new;


}
//This function dynaimcally expands the array that holds the address space for each message that belongs to a message box.
char ** word_arr1(char ** old_arr,int length,int size){
	char **new = malloc(sizeof(char*)*size);
	int i = 0;
	new[size] = malloc(sizeof(char*)*length);
	for(i=0;i<size;i++){
		new[i] = old_arr[i];
	}
	messages = new;

}
//This function check the creation of a messgae box and makes sure the name fits the critiera.
int word_check(char * word,int size){
	int correct =0;
	int i = 0;
	if(size < 5){
		correct = 1;
	}
	if(size > 25){
		correct = 2;
	}
	if(isalpha(word[0]) == 0){
		correct = 3;
	}
	return correct; 

}
//This function checks wheather or not a message box with the same name has been created.
int present(char ** arr, char* word,int size){
	int i = 0;
	int found = 0;
	for(i =0; i < size; i++){
		if(strcmp(arr[i],word) == 0){
			found = 1;
		}
	}
	return found;

}
//This function finds the location of a message box
int locate(char **arr,char * word,int size){
	int found = 0;
	int i = 0;
	for(i =0; i < size; i++){
		if(strcmp(word,arr[i]) == 0){
			found = i;
		}
	}
	return found;

}
//This is the Thread function
void * socketThread(void * args){
	time_t s, val = 1;
	struct tm* current_time;
	s = time(NULL);
	int hours, minutes, seconds;
	current_time = localtime(&s);
	hours = current_time->tm_hour;
	minutes = current_time->tm_min;
	char Ip[50];
	char * hello = "HELLO DUMBv0 ready!";
	char message[5];
	int socketfd = *((int*)args);
	int number1 = 0;
	int spot = 0;
	int in_use = -1;
	int counter = 0;
	int err1 = 0;
	read(socketfd,Ip,50);
	Ip[50]= '\0';
	int length1 = 0; 
    	read(socketfd,message,5);
	message[5] = '\0';
	/*checking to see if the client sent the correct message
	to the server else the server sends back an error message.
	*/
    	if(strcmp(message,"HELLO") == 0){
		server_events(message,Ip,0,number1);
    		write(socketfd,hello,strlen(hello));
    	}
	else if (strcmp(message,"HELLO") != 0){
		write(socketfd,"ERROR",6);
	}
	bzero(message,5);
	//While loop iterates until client enters in quit command
	while(strcmp(message,"GDBYE")!= 0){
		read(socketfd,message,5);
		message[5] = '\0';
		/*This if statement handles the creation of 
		message boxes.	
		*/
		if(strcmp(message,"CREAT") == 0){
			//locking the current thread
			pthread_mutex_lock(&create);
			//char input[25];
			char number[4];
			read(socketfd,number,4);
			int length = atoi(number);
			/*If this is the first message box created malloc the space for it
			else call word_arr to increase the size of the array to fit one more 
			index.
			*/
			if(loc == 0){
				int i =0;
				word1 = malloc(sizeof(char*)*1);			
				word1[0] = malloc(sizeof(char*)*length);
				read(socketfd,word1[loc2],length);
				word1[loc2][length] = '\0';
				err1 = 0;
			}
			
			else {
				word_arr(word1,length,loc2);
				read(socketfd,word1[loc2],length);
				word1[loc2][length] = '\0';
				//checking to see if the message box exits
				if(present(word1,word1[loc2],loc2) == 1){
					err1 = 5;			

				}
			}		
			int ret =0;
			if(err1 != 5){
				err1 = word_check(word1[loc2],length);
			}
			//displayes server events
			ret = server_events(message,Ip,err1,number1);
			int exists = 0;
			int start =0;
			//If thier are no errors then a queue is created and inialized inside of a queue array
			if(ret == 0){
				/*If this is the first message box created malloc the space for it
				else call new to increase the size of the array to fit one more 
				index.
				*/
				if(loc2 == 0){
					q = (struct Queue**)malloc(sizeof(struct Queue)*(20000));
					*(q+0) = createQueue();
				}
				else if(loc2 > 0){
					*(q+loc2) = createQueue();
				}
				if(exists == 0){
					write(socketfd,"OK!",9);
					write(socketfd,"",1);
					pthread_mutexattr_init(&Attr[loc2]);
				        pthread_mutexattr_settype(&Attr[loc2],PTHREAD_MUTEX_ERRORCHECK);
					pthread_mutex_init(&lock[loc2],&Attr[loc2]);
				}
				counter++;
				loc2++;
				exists = 0;			
			}
			/*These two if statements send errors to the client if an error has occured. 
				
			*/
			if(ret == 1 && err1 == 5){
				write(socketfd,"OK!",9);
				write(socketfd,"ER:EXIST",9);
			}
			if(ret == 1 && err1 != 5){
				write(socketfd,"ER:WHAT?",9);
				write(socketfd,"",1);
			}
			err1 = 0;
			//unlocking the create mutex_lock
			pthread_mutex_unlock(&create);
		}//end if if
		//This if statement handles the delete command operation
		if(strcmp(message,"DELBX")==0){
			int err = 0;
			char number[4];
			read(socketfd,number,4);
			int length = atoi(number);
			char input[length];
			read(socketfd,input,length);
			input[length] = '\0';
			//checking if the message box entered exists.
			if(present(word1,input,loc2) == 1){
				//finding the exact location of the message box
				spot = locate(word1,input,loc2);
				//attempting to lock the thread that wants to delete the message box
				int ret_val = pthread_mutex_trylock(&lock[spot]);
				// if the lock succeeds then do further checking
 				if(ret_val == 0){
					//checking to see if the message box is empty
					char * front1 = front(q[spot]);
					if(front1 == NULL){
						//place a " " in the index of word1 array signifying that the message box has been deleted
						word1[spot] = " ";
					}
					//if the message box still has messages then do not delete message box
					else if(front1 != NULL){
						fprintf(stderr,"%02d%02d %d %s %s ER:NOTMT\n",hours,minutes,current_time->tm_mday,"Dec",Ip);	
						write(socketfd,"ER:NOTMT",9);
					}
					//unlock the mutex lock the thread possessed
					pthread_mutex_unlock(&lock[spot]);
					if(in_use > -1){
						pthread_mutex_trylock(&lock[in_use]);
					}
				}
				/*These conditional statements display the correct server events and send the server out
				puts to the client. 
				*/
				else if(ret_val > 0){
					fprintf(stderr,"%02d%02d %d %s %s ER:OPEND\n",hours,minutes,current_time->tm_mday,"Dec",Ip);	
					if(in_use > -1){
						pthread_mutex_trylock(&lock[in_use]);
					}
					write(socketfd,"ER:OPEND",9);
				}
				else if(front(q[spot]) == NULL){
					fprintf(stderr,"%02d%02d %d %s %s ER:NOTMT\n",hours,minutes,current_time->tm_mday,"Dec",Ip);	
					write(socketfd,"ER:NOTMT",9);
				}		
				if(word1[spot] == " "){
					server_events(message,Ip,err,number1);
					write(socketfd,"OK!",9);
				}
				
			}
			/*These conditional statements display the correct server events and send the server out
			puts to the client. 
			*/
			else if(length < 5 ||length > 25 || isalpha(input[0])== 0){
				fprintf(stderr,"%02d%02d %d %s %s ER:WHAT?\n",hours,minutes,current_time->tm_mday,"Dec",Ip);
				write(socketfd,"ER:WHAT?",9);

			}
			else if(length >=5 && length <= 25 && isalpha(input[0])!= 0){
				fprintf(stderr,"%02d%02d %d %s %s ER:NEXST\n",hours,minutes,current_time->tm_mday,"Dec",Ip);
				write(socketfd,"ER:NEXST",9);
			}


		}
		//This if statement handles the open command
		if(strcmp(message,"OPNBX") == 0 ){
			//char input[30];
			char number[4];
			read(socketfd,number,4);
			int length = atoi(number);
			char input[length];
			read(socketfd,input,length);
			input[length] = '\0';
			int err = word_check(input,length);
			int ret = server_events(message,Ip,err,number1);
			//checking if thier are no errors from the server_events function and that the user currently does not have a 
			//message box open.
			if(ret == 0 && in_use == -1){
				if(loc2 > 0){
					//checking if the message box exists
					if(present(word1,input,loc2) == 1){
						//getting the location of the message box
						spot = locate(word1,input,loc2);
						//attempting to lock the thread to have access to that message box.
						int ret_val = pthread_mutex_trylock(&lock[spot]);
						//If if that lock is accessed by another thread then an OPEND error occurs
						if(ret_val > 0 ){
							fprintf(stderr,"%02d%02d %d %s %s ER:OPEND\n",hours,minutes,current_time->tm_mday,"Dec",Ip);
							write(socketfd,"ER:OPEND",9);
							
						}
						//Else the thread gained access to that message box.
						if(ret_val == 0){
							server_events(message,Ip,6,number1);
							in_use = spot;
							write(socketfd,"OK!",9);
						}
					}
				}
				//checking to see if the message box even exits if not it throws an error
				if(loc2 > 0){
					if(present(word1,input,loc2) == 0 ){
						server_events(message,Ip,5,number1);
						write(socketfd,"ER:NEXST",9);	
					}
				}
				//If it has no message box then clearly the message box dose not exist.
				if(loc2 == 0){
					server_events(message,Ip,5,number1);
					write(socketfd,"ER:NEXST",9);	
				}
			}
			else if(ret == 1){
				write(socketfd,"ER:WHAT?",9);
			}
			//EXTRA CREDIT
			//This conditional statement checks if the user already has a message box open
			else if(in_use > -1 && ret == 0){
				fprintf(stderr,"%02d%02d %d %s %s ER:ARLDY\n",hours,minutes,current_time->tm_mday,"Dec",Ip);
				write(socketfd,"ER:ARLDY",9);
			}
		}// end of if statement
		//this if statment handles the close command
		if(strcmp(message,"CLSBX")==0){
			char number[4];
			read(socketfd,number,4);
			int length = atoi(number);
			char input[length];
			read(socketfd,input,length);
			input[length] = '\0';
			int ret = 0;
			//locating the message box if it exists and input is correct
			spot = locate(word1,input,loc2);
			if(loc2 > 0){
				//checking to see if the message box entered is the same message box that the user wants to close 
				if(strcmp(word1[spot],input) == 0){
					int err = word_check(input,length);
					if(err > 0 ){
						ret = server_events(message,Ip,err,number1);
					}
					//attempting to access the lock to unlock the thread to close the message box
					if(ret == 0){
						int val = pthread_mutex_unlock(&lock[spot]);
						//if unlock dose not succeed then error is returned to server and client
						if(val> 0){
								fprintf(stderr,"%02d%02d %d %s %s ER:NOOPN\n",hours,minutes,current_time->tm_mday,"Dec",Ip);
					                        write(socketfd,"ER:NOOPN",9);
						}
						//if unlock succeeds then user no longer has access to that message box
						if(val==0){
							server_events(message,Ip,err,number1);
							write(socketfd,"OK!",9);
							in_use = -1;
						}

					}
				}
			//Further error checking 
				else if(length >=5 && length <= 25 && isalpha(input[0])!= 0){
					fprintf(stderr,"%02d%02d %d %s %s ER:NOOPN\n",hours,minutes,current_time->tm_mday,"Dec",Ip);
					write(socketfd,"ER:NOOPN",9);
				}
				else if(length < 5 ||length > 25 || isalpha(input[0])== 0){
					fprintf(stderr,"%02d%02d %d %s %s ER:WHAT?\n",hours,minutes,current_time->tm_mday,"Dec",Ip);
					write(socketfd,"ER:WHAT?",9);

				}
			}
			else{

				fprintf(stderr,"%d%d %d %s %s ER:NOOPN\n",hours,minutes,current_time->tm_mday,"Dec",Ip);
					write(socketfd,"ER:NOOPN",9);
			}
		

		}//end of if statement
		//This is statement handles the put command
		if(strcmp(message,"PUTMG")==0){
			char buf[9];
			char readn[4];
			//checks if the user dose not have a message box open
			if(in_use == -1){
				write(socketfd,"ER:NOOPN",9);
				char char1[9];
				read(socketfd,char1,9);
				char1[9] = '\0';
				if(strcmp(char1,"ER:NOOPN") == 0){
					fprintf(stderr,"%02d%02d %d %s %s ER:NOOPN\n",hours,minutes,current_time->tm_mday,"Dec",Ip);
				}
			}
			if(in_use > -1){
				write(socketfd," ",1);
			}
			//if the user has message box open
			if(in_use > -1){
				//reciving commands from client to see if user enter in the command correctly
				read(socketfd,buf,9);
				buf[9] = '\0';
				//If the message is the correct format
				if(strcmp(buf,"OK!") == 0){
					read(socketfd,readn,4);
					int num = atoi(readn);
					//allocate space for the message in an array and store the message in the correct message box
					if(index == 0){
						messages = malloc(sizeof(char*)*1);
						messages[0] = malloc(sizeof(char*)*num);
						read(socketfd,messages[index1],num);
						messages[0][num] = '\0';
						enqueue(q[in_use],messages[0]);
					}
					else{
						messages = word_arr1(messages,num,index1);
						read(socketfd,messages[index1],num);
						messages[index1][num] = '\0';
						enqueue(q[in_use],messages[index1]);
					}
					server_events(message,Ip,0,number1);
					index1++;
				}
			}
			
			
	    	}//end of if statement
		//this if statement handles the next command
		if(strcmp(message,"NXTMG") ==0){
			//checking to see if the user has a message box open
			if(in_use == -1){
				fprintf(stderr,"%02d%02d %d %s %s ER:NOOPN\n",hours,minutes,current_time->tm_mday,"Dec",Ip);
				write(socketfd,"ER:NOOPN",9);
			}
			//if the messgae box is open
			if(in_use > -1){
				//keep on dequeue from the list until the head is NULL in the queue
				char * deq = dequeue(q[in_use]);
				int end = 0;
				if(deq != NULL){
					char * good = "OK!";
					//write(socketfd,good,9);
					server_events(message,Ip,0,number1);
					int length2 = strlen(deq);
					char number4[4];
					sprintf(number4,"%d",length2);
					write(socketfd,good,9);
					write(socketfd,number4,4);
					write(socketfd,deq,length2);
					
				}
				//sends a message to server and client that the list is empty
				else if (deq == NULL){
					fprintf(stderr,"%02d%02d %d %s %s ER:EMPTY\n",hours,minutes,current_time->tm_mday,"Dec",Ip);
					write(socketfd,"ER:EMPTY",9);
				}
			}
			
		}//end of if statement
		//This if statement handles if bad commands were entered
		if(strcmp(message,"ERRRR")==0){
			server_events(message,Ip,69,number1);
			write(socketfd,"ER:WHAT?",9);
	    	}
		//This if statement handles the quit command from the user
		//closing the socket and unlocking the thread if it has not already
		if(strcmp(message,"GDBYE") == 0){

			server_events(message,Ip,0,number1);
			if(in_use >-1){
				pthread_mutex_unlock(&lock[in_use]);	
			}
			
			close(socketfd);
	    	}

	}
	return NULL;
}//end of thread function

// Driver function 
int main(int argc,char * argv[]) 
{ 
    time_t s, val = 1;
    struct tm* current_time;
    s = time(NULL);
    current_time = localtime(&s);
    int sockfd,connfd,len;
    struct sockaddr_in servaddr, cli; 
    char * hello = "HELLO DUMBv0 ready!";
    char Ip[50];
    char message[5];
    char * word;
    int number = 0;
    int err = 0;
    if(argc > 2 || argc < 2){
	printf("Incorrect amount of arugments have been entered\n");
	exit(0);
    }
    char * port = argv[1];
    int portno = atoi(port); 
    if(portno < 4000){
	printf("Port number you have entered is not greater than 4000\n");
	exit(0);
    }
    // socket create and verification 
    sockfd = socket(AF_INET, SOCK_STREAM, 0); 
    if (sockfd == -1) { 
        printf("socket creation failed...\n"); 
        exit(0); 
    } 
    else
       
    bzero(&servaddr, sizeof(servaddr)); 
  
    // assign IP, PORT 
    servaddr.sin_family = AF_INET; 
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
    servaddr.sin_port = htons(portno); 
  
    // Binding newly created socket to given IP and verification 
    if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) { 
        printf("socket bind failed...\n"); 
        exit(0); 
    } 
    else
        
  
    // Now server is ready to listen and verification 
    if ((listen(sockfd, 50)) != 0) { 
        printf("Listen failed...\n"); 
        exit(0); 
    } 
    else
        
    len = sizeof(cli); 
    while(1){
	    // Accept the data packet from client and verification 
	    connfd = accept(sockfd, (SA*)&cli, &len); 
	    if (connfd < 0) { 
		printf("server acccept failed...\n"); 
		exit(0); 
	    } 
	    else
		//creating a thread every time a client connects to the server 
		err = (pthread_create(&id[loc],NULL,socketThread,&connfd));
		if(err){
			fprintf(stderr,"An error has occurred creating the thread\n");
		}
		loc++;
		int i =0;
		
	}
	int i = 0;
	//joining all the threads that have been created
	for(i =0; i < loc; i++){
		int flag = pthread_join(id[i],NULL);
		//error checking
		if(flag){
			fprintf(stderr,"Server exited with exit status %d\n",flag);	
		}
	}
	i =0;
	//destroying all used locks
	for(i = 0; i < loc2;i++){
		pthread_mutex_destroy(&lock[i]);
	}
	pthread_mutex_destroy(&create);
	//freeing all of the memory.
	free(q);
	free(word1);
	free(messages);
	
   
} 

