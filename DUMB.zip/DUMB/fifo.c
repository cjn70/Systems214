#include <stdio.h> 
#include <stdlib.h> 

struct Node{
	char * message;
	struct Node * next;

};
struct Queue{
	struct Node *front,*rear;
};
//create a new node and insert new contents of that node
struct Node* newNode(char * k){
	struct Node * temp = (struct Node*)malloc(sizeof(struct Node));
	temp->message = k;
	temp->next = NULL;
	return temp;
}
//creates empty queue
struct Queue* createQueue(){
	struct Queue * q = (struct Queue*)malloc(sizeof(struct Queue));
	q->front = q->rear = NULL;
	return q;

}
//put new message in the message box
void enqueue(struct Queue* q,char * message){
	struct Node * temp = newNode(message);
	
	if(q->rear == NULL){
		q->front = q->rear = temp;
		return;
	}
	//add a new node at the end of the linked list
	q->rear->next = temp;
	q->rear = temp;

}
//this function removes the messages FIFO from the queue
char * dequeue(struct Queue* q)
{
	if(q->front == NULL){
		return '\0';
	}
	struct Node* temp = q->front;
	char* tempMessage = q->front->message;
	q->front = q->front->next;
	free(temp);
	if(q->front == NULL){
		q->rear = NULL;
	}	
	return(tempMessage);
	
}
//this function gets the message at the first node
char * front(struct Queue * q){
	char * message1;
	if(q->front == NULL){
		message1 = '\0';
	}
	else{
		message1 = q->front->message;
	}
	return message1;
}























