#ifndef _HEADER_H
#define _HEADER_H
struct Node{
	char* name;
	char * message;
	struct Node * next;
};

struct Queue{
	struct Node *front, *rear;
};
struct Queue * createQueue();
char * dequeue(struct Queue * q);
char * front(struct Queue * q);
#endif
